module.exports = {
  baseUrl: 'https://www.saucedemo.com/'
};
